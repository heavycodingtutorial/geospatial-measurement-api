from pathlib import Path
import geopandas as gpd
from shapely.geometry import Polygon, LineString, Point
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)

def create_test_kml(path: Path):
    gdf = gpd.GeoDataFrame(
        {
            "name": ["test-polygon", "test-line", "test-point"],
            "geometry": [
                Polygon([(72.0, 19.0), (72.01, 19.0), (72.01, 19.01), (72.0, 19.01)]),
                LineString([(72.0, 19.0), (72.02, 19.02)]),
                Point(72.0, 19.0),
            ]
        },
        crs="EPSG:4326"
    )
    # Writing KML requires a GDAL/Fiona setup that supports KML.
    gdf.to_file(path, driver="KML")

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_invalid_extension():
    response = client.post(
        "/api/files/",
        files={"file": ("test.txt", b"hello", "text/plain")}
    )
    assert response.status_code == 400
