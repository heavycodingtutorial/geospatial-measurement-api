from fastapi import FastAPI
from app.api.files import router as files_router
from app.database import Base, engine

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Geospatial File Measurement API",
    version="1.0.0",
    description="Upload Shapefile ZIP/KML files and calculate geospatial measurements."
)

app.include_router(files_router, prefix="/api/files", tags=["Files"])

@app.get("/health")
def health():
    return {"status": "ok"}
