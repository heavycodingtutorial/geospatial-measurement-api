from typing import Any, Optional
from pydantic import BaseModel

class FileInfo(BaseModel):
    id: str
    filename: str
    feature_count: int
    crs: Optional[str]
    status: str

class MeasurementItem(BaseModel):
    feature_id: int
    geometry_type: str
    properties: dict[str, Any]
    measurement: Optional[dict[str, Any]] = None
    status: str

class MeasurementsResponse(BaseModel):
    file_id: str
    filename: str
    feature_count: int
    items: list[MeasurementItem]
