from sqlalchemy import Column, String, Integer, Text
from app.database import Base

class GeoFile(Base):
    __tablename__ = "geo_files"

    id = Column(String, primary_key=True, index=True)
    filename = Column(String, nullable=False)
    stored_path = Column(String, nullable=False)
    feature_count = Column(Integer, default=0)
    crs = Column(String, nullable=True)
    status = Column(String, nullable=False, default="PROCESSING")
    error_message = Column(Text, nullable=True)
