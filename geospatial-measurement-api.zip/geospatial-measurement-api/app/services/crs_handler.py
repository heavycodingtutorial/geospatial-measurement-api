import geopandas as gpd
from pyproj import CRS

def choose_projected_crs(gdf: gpd.GeoDataFrame) -> CRS:
    """
    Choose a metric CRS suitable for the dataset.
    For geographic CRS, UTM is preferred when possible via GeoPandas estimate_utm_crs.
    For projected CRS, retain the source CRS.
    """
    if gdf.crs is None:
        raise ValueError("Input file does not contain a CRS.")

    source = CRS.from_user_input(gdf.crs)

    if source.is_projected:
        return source

    estimated = gdf.estimate_utm_crs()
    if estimated is not None:
        return CRS.from_user_input(estimated)

    # Fallback to Web Mercator when an automatic UTM estimate is unavailable.
    return CRS.from_epsg(3857)
