from typing import Any
import geopandas as gpd
from shapely.geometry import Polygon, MultiPolygon, LineString, MultiLineString
from app.services.crs_handler import choose_projected_crs

SUPPORTED_POLYGONS = (Polygon, MultiPolygon)
SUPPORTED_LINES = (LineString, MultiLineString)

def calculate_measurements(gdf: gpd.GeoDataFrame) -> list[dict[str, Any]]:
    projected_crs = choose_projected_crs(gdf)
    projected = gdf.to_crs(projected_crs)

    results = []

    for index, (original_geom, metric_geom) in enumerate(
        zip(gdf.geometry, projected.geometry)
    ):
        geometry_type = original_geom.geom_type if original_geom is not None else "Unknown"
        properties = {
            str(k): v for k, v in gdf.iloc[index].drop(labels=["geometry"]).to_dict().items()
        }

        item = {
            "feature_id": index,
            "geometry_type": geometry_type,
            "properties": properties,
            "measurement": None,
            "status": "NO_MEASUREMENT"
        }

        if metric_geom is None or metric_geom.is_empty:
            item["status"] = "INVALID_OR_EMPTY_GEOMETRY"
        elif isinstance(metric_geom, SUPPORTED_POLYGONS):
            item["measurement"] = {
                "area": round(float(metric_geom.area), 4),
                "unit": "square_meters"
            }
            item["status"] = "MEASURED"
        elif isinstance(metric_geom, SUPPORTED_LINES):
            item["measurement"] = {
                "length": round(float(metric_geom.length), 4),
                "unit": "meters"
            }
            item["status"] = "MEASURED"
        elif geometry_type == "Point":
            item["status"] = "POINT_NO_MEASUREMENT"
        else:
            item["status"] = "UNSUPPORTED_GEOMETRY"

        results.append(item)

    return results
