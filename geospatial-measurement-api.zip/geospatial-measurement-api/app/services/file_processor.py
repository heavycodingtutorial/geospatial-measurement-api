from pathlib import Path
import geopandas as gpd

SUPPORTED_EXTENSIONS = {".kml", ".zip"}

def _find_shapefile(zip_dir: Path) -> Path:
    shp_files = list(zip_dir.rglob("*.shp"))
    if not shp_files:
        raise ValueError("ZIP file does not contain a .shp file.")
    return shp_files[0]

def read_geospatial_file(path: Path) -> gpd.GeoDataFrame:
    suffix = path.suffix.lower()

    if suffix == ".kml":
        try:
            return gpd.read_file(path, driver="KML")
        except Exception:
            # Some GDAL installations detect KML automatically.
            return gpd.read_file(path)

    if suffix == ".zip":
        import zipfile
        import tempfile

        temp_dir = Path(tempfile.mkdtemp(prefix="shapefile_"))
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(temp_dir)

        shp = _find_shapefile(temp_dir)
        return gpd.read_file(shp)

    raise ValueError("Only .kml and .zip (Shapefile ZIP) files are supported.")
