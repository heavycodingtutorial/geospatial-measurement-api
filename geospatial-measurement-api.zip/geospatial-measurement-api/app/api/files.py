from pathlib import Path
from uuid import uuid4
import shutil

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import GeoFile
from app.schemas import FileInfo, MeasurementsResponse
from app.services.file_processor import read_geospatial_file
from app.services.measurement import calculate_measurements

router = APIRouter()
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=FileInfo, status_code=201)
async def upload_file(file: UploadFile = File(...), db: Session = Depends(get_db)):
    suffix = Path(file.filename or "").suffix.lower()

    if suffix not in {".kml", ".zip"}:
        raise HTTPException(
            status_code=400,
            detail="Only .kml and .zip (Shapefile ZIP) files are supported."
        )

    file_id = str(uuid4())
    destination = UPLOAD_DIR / f"{file_id}{suffix}"

    try:
        with destination.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        gdf = read_geospatial_file(destination)
        crs_text = gdf.crs.to_string() if gdf.crs else None

        record = GeoFile(
            id=file_id,
            filename=file.filename,
            stored_path=str(destination),
            feature_count=len(gdf),
            crs=crs_text,
            status="COMPLETED"
        )
        db.add(record)
        db.commit()
        db.refresh(record)

        return record

    except Exception as exc:
        db.rollback()
        record = GeoFile(
            id=file_id,
            filename=file.filename,
            stored_path=str(destination),
            feature_count=0,
            crs=None,
            status="FAILED",
            error_message=str(exc)
        )
        db.add(record)
        db.commit()

        raise HTTPException(status_code=422, detail=f"File processing failed: {exc}")

@router.get("/{file_id}/", response_model=FileInfo)
def get_file(file_id: str, db: Session = Depends(get_db)):
    record = db.get(GeoFile, file_id)
    if not record:
        raise HTTPException(status_code=404, detail="File not found")
    return record

@router.get("/{file_id}/measurements/", response_model=MeasurementsResponse)
def get_measurements(file_id: str, db: Session = Depends(get_db)):
    record = db.get(GeoFile, file_id)
    if not record:
        raise HTTPException(status_code=404, detail="File not found")

    if record.status != "COMPLETED":
        raise HTTPException(
            status_code=422,
            detail=f"Measurements unavailable because file status is {record.status}"
        )

    try:
        gdf = read_geospatial_file(Path(record.stored_path))
        items = calculate_measurements(gdf)

        return {
            "file_id": record.id,
            "filename": record.filename,
            "feature_count": record.feature_count,
            "items": items
        }
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Measurement calculation failed: {exc}")
